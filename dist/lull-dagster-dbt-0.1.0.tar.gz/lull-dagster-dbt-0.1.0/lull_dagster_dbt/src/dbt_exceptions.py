class DBTRunTimeoutException(Exception):
    pass


class DBTNoJobIdException(Exception):
    pass


class DBTNoRunIdException(Exception):
    pass
