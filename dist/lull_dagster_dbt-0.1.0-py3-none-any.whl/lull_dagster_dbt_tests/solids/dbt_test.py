import pytest, pdb
from dbt.ops.dbt_ops import *


class TestDBTSolids:
    def test_trigger_job(self):
        pass
